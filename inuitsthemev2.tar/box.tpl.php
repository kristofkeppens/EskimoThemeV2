<div class="box">

<?php if ($title): ?>
  <h3><?php print $title ?></h3>
<?php endif; ?>

  <div class="content"><?php print $content ?></div>
</div>
